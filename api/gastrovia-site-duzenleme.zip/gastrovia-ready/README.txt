GASTROVIA SITE PAKETİ

Dosyalar:
- index.html: ana sayfa ve mevcut Akıllı Mutfak / yapay zekâ alanlarını koruyan düzenlenmiş sayfa.
- tarif.html: 20 tarif için ayrı sayfa; URL tarif.html?id=slug şeklinde açılır.
- assets/tarif-01.png ve assets/tarif-02.png: kullanıcının gönderdiği ilk iki fotoğraf.

GitHub deposunda kök dizine index.html ve tarif.html dosyalarını; assets klasörünü de içindeki iki fotoğrafla birlikte yükle. api/recipe.js dosyasına dokunma. Diğer 18 kartta yanlış fotoğraf göstermek yerine fotoğraf alanı bilerek boş/uyumlu yer tutucu bırakıldı.

Not: Tarif içerikleri başlangıç taslağıdır; yayımdan önce ölçü, pişme süresi ve besin değerleri mutfak testinden geçirilmelidir.
